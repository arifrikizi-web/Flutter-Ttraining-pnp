package com.example.flutter_trainingday1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
